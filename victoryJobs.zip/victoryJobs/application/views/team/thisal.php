<section class="job-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-7 co-xs-12 text-left">
                        <h3>THISAL ALUTHGE</h3>
                    </div>
                    <div class="col-md-6 col-sm-5 co-xs-12 text-right">
                        <div class="bread">
                            <ol class="breadcrumb">
                                <li><a href="#">Home</a> </li>
                                <li class="active">Team</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12 nopadding">
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="about-image">
                                <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/users/profiles/thisal.png" alt="">
                            </div>                            
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="resume-box">
                                <div class="heading-inner">
                                    <p class="title">Personal Information</p>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                        <div class="my-contact">
                                            <div class="contact-icon">
                                                <span class="icon-profile-female"></span>
                                            </div>
                                            <div class="contact-info">
                                                <h4>Name: </h4>
                                                <p>Thisal Aluthge </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                        <div class="my-contact">
                                            <div class="contact-icon">
                                                <span class=" icon-envelope"></span>
                                            </div>
                                            <div class="contact-info">
                                                <h4>Email: </h4>
                                                <p></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                        <div class="my-contact">
                                            <div class="contact-icon">
                                                <span class=" icon-phone"></span>
                                            </div>
                                            <div class="contact-info">
                                                <h4>Phone: </h4>
                                                <p></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                        <div class="my-contact">
                                            <div class="contact-icon">

                                                <span class="icon-calendar"></span>
                                            </div>
                                            <div class="contact-info">
                                                <h4>Date Of birth: </h4>
                                                <p></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                        <div class="my-contact">
                                            <div class="contact-icon">
                                                <span class="icon-map-pin"></span>
                                            </div>
                                            <div class="contact-info">
                                                <h4>Address: </h4>
                                                <p></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                        <div class="my-contact">
                                            <div class="contact-icon">
                                                <span class="icon-flag"></span>
                                            </div>
                                            <div class="contact-info">
                                                <h4>Nationality: </h4>
                                                <p></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <p class="about-me">We are a Job Portal and Recruitment and Headhunting agency with a difference. A handpicked pool of professionals with diverse experience and expertise are at the heart of the company’s operations and are wholeheartedly committed to curating the cream of opportunities for the job seekers of Sri Lanka. Our aim is to be HR’s Pitstop where all the needs of a jobseeker will be met beyond expectation.</p>
                               <p class="about-me">Thisal Aluthge who will be joining Victory Jobs in the capacity of Senior Consultant of our Talent Acquisition team is a registered tax agent and qualified accountant with over 20 years’ experience in taxation, accounting, bookkeeping and auditing. </p>
                               <p class="about-me">He has number of accounting qualifications including CPA (Au) and CA (SL). He is a Xero certified advisor, MYOB partner and Quick Books certified pro-advisor. </p>
                               <p class="about-me">Victory Jobs is fortunate to have onboard an accounting professional of Thisal’s caliber who will set our books straight from inception.</p>
                               <p class="about-me">We warmly welcome you Thisal and offer our congratulations and best wishes!</p>
                            </div>
                        </div>    
                    </div>
                </div>
            </div>
        </section>